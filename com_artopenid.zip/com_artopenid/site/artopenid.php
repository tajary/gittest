<?php
defined('_JEXEC') or die('Restricted Access');

// Require the base controller
require_once( JPATH_COMPONENT.DIRECTORY_SEPARATOR.'functions.php' );
jimport('joomla.application.component.controller');

/*
$controller = JControllerLegacy::getInstance('ArtOpenID');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
*/
$task = @$_GET['task'];
$artsecret = "Fshds&*hsd76GH90dfj^&";
$ustate = md5($artsecret.$_SERVER['HTTP_USER_AGENT'].$_SERVER['REMOTE_ADDR'].$artsecret);
if(!$task){
    artOpenIdGoToOP($ustate);
}
if($task=='process'){
    $code = $_GET['code'];
    $state = $_GET['state'];
    if($state != $ustate) die("Who Are You?");
    if(isset($_GET['error'])) die("err");
    $uinfo = artOpenIdReturnFromOP($code);
    $email = $uinfo['email'];
    $password = md5('apple');    
    $db = JFactory::getDbo();
    $app = JFactory::getApplication();
    $session =& JFactory::getSession();
    $sql = "SELECT * FROM #__users WHERE email =" . $db->quote($email);
    $db->setQuery($sql);
    $result = $db->loadObject();

    if($result->id){
        $jUser = JFactory::getUser($result->id);
        $instance = $jUser;     
        $instance->set('guest', 0);

        // Register the needed session variables

        $session->set('user',$jUser);


        // Check to see the the session already exists.                        
        $app->checkSession();

        // Hit the user last visit field
        $instance->setLastVisit();          
        $app->redirect(JURI::base());
        //return true;
    }else{
        $firstname = $email; // generate $firstname
        $lastname = ''; // generate $lastname
        $username = $email; // username is the same as email


        /*
        I handle this code as if it is a snippet of a method or function!!

        First set up some variables/objects     */

        // get the ACL
        $acl =& JFactory::getACL();

        /* get the com_user params */

        jimport('joomla.application.component.helper'); // include libraries/application/component/helper.php
        $usersParams = &JComponentHelper::getParams( 'com_users' ); // load the Params

        // "generate" a new JUser Object
        $user = JFactory::getUser(0); // it's important to set the "0" otherwise your admin user information will be loaded

        $data = array(); // array for all user settings

        // get the default usertype
        $usertype = $usersParams->get( 'new_usertype' );
        if (!$usertype) {
            $usertype = 'Registered';
        }

        // set up the "main" user information

        //original logic of name creation
        //$data['name'] = $firstname.' '.$lastname; // add first- and lastname
        $data['name'] = $firstname.$lastname; // add first- and lastname

        $data['username'] = $username; // add username
        $data['email'] = $email; // add email
        $data['gid'] = 10;

        /* no need to add the usertype, it will be generated automaticaly from the gid */

        $data['password'] = $password; // set the password
        $data['password2'] = $password; // confirm the password
        $data['sendEmail'] = 1; // should the user receive system mails?

        /* Now we can decide, if the user will need an activation */

        $useractivation = 0; // in this example, we load the config-setting
        if ($useractivation == 1) { // yeah we want an activation
            jimport('joomla.user.helper'); // include libraries/user/helper.php
            $data['block'] = 0; // block the User
            $data['activation'] =JUtility::getHash( JUserHelper::genRandomPassword() ); // set activation hash (don't forget to send an activation email)
        }
        else { // no we need no activation
            $data['block'] = 1; // don't block the user
        }

        if (!$user->bind($data)) { // now bind the data to the JUser Object, if it not works....
            JError::raiseWarning('', JText::_( $user->getError())); // ...raise an Warning
            return false; // if you're in a method/function return false
        }

        if (!$user->save()) { // if the user is NOT saved...
            JError::raiseWarning('', JText::_( $user->getError())); // ...raise an Warning
            return false; // if you're in a method/function return false
        }

        //echo '<br/>'.'User registration is completed'.'<br/>';


        $jUser = $user;
        $instance = $jUser;     
        $instance->set('guest', 0);

        // Register the needed session variables

        $session->set('user',$jUser);


        // Check to see the the session already exists.                        
        $app->checkSession();

        // Hit the user last visit field
        $instance->setLastVisit();          
        $app->redirect(JURI::base());
    }    
}
