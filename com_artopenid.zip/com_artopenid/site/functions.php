<?php
defined('_JEXEC') or die('Restricted Access');

function artOpenIdGoToOP(){
    $clientId = "test";
    $url = "https://85.133.186.185:44333/core/connect/authorize?";
	$postFields = array(
	    "response_type"=>"code",
	    "scope"=>"openid profile email",
	    "client_id"=>$clientId,
	    "redirect_uri"=>JURI::base()."index.php?option=com_artopenid&task=process",
	);
    $url.=http_build_query($postFields);
    header("location: $url");
    exit;
}

function artOpenIdReturnFromOP($code){
	$clientSecret = "secret";
    $ch = curl_init("https://85.133.186.185:44333/core/connect/token");

	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
	curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );    # required for https urls
	
	curl_setopt( $ch, CURLOPT_MAXREDIRS, 10 );
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	    'Authorization: Basic ' . $clientSecret
	    ));
	curl_setopt( $ch, CURLOPT_POST, true);
	curl_setopt( $ch, CURLOPT_POSTFIELDS, "code=" . $code . "&grant_type=authorization_code");
	$content = curl_exec($ch);

	if(curl_errno($ch)){
	   echo 'Request Error:' . curl_error($ch);
	   exit();
	}
	

	curl_close($ch);

    $jObj = json_decode($content);
    $access_token = $jObj->access_token;
    
    $ch = curl_init("https://85.133.186.185:44333/core/connect/userinfo");
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
	curl_setopt( $ch, CURLOPT_ENCODING, "" );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
	curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );    # required for https urls
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	    'Authorization: Bearer ' . $access_token
	    ));
	
	$content = curl_exec($ch);

	if(curl_errno($ch))
		{
		    echo 'error:' . curl_error($ch);
		    exit();
		}
	
	curl_close($ch);
	return json_decode($content, true);
	//return $content;	
    
    
}

function artOpenIdCreateUser(){
    
}